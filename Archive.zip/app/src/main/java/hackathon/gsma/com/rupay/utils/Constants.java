package hackathon.gsma.com.rupay.utils;

/**
 * Created by issy on 7/8/17.
 */

public class Constants {

    public static final String HOST = "http://172.27.34.27:1190/";
    public static final String BASE_URL = "v0.14/MM/";

}
